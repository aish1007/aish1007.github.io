const doAsync = async () => {
  const path = require("path");
  const HtmlWebpackPlugin = require("html-webpack-plugin");
  const {
    getMyInfo,
    getTechnicalSkills,
    getExperience,
    getEducation,
    getProject,
  } = require("./content-service/contentTypes.js");

  var basicDetails = await getMyInfo();
  var techSkills = await getTechnicalSkills();
  var experience = await getExperience();
  var education = await getEducation();
  var project = await getProject();

  //technical skills
  let skillsNames = techSkills.map(({ fields }) => fields.name);
  let skills = techSkills.map(({ fields }) => fields.list);

  var skill1 = skills[0].split(",");
  var skill2 = skills[1].split(",");
  var skill3 = skills[2].split(",");
  var skill4 = skills[3].split(",");

  //work experience
  let position = experience.map(({ fields }) => fields.position);
  let duration = experience.map(({ fields }) => fields.duration);
  let company = experience.map(({ fields }) => fields.company);
  let description = experience.map(({ fields }) => fields.description);

  description = description.toString().replace(/(\r\n|\n|\r)/gm, " ");
  const regex = /theend,&#9679/gi;
  let desc = description.replace(regex, "theend &#9679");

  //education
  let degree = education.map(({ fields }) => fields.degree);
  let place = education.map(({ fields }) => fields.place);
  let year = education.map(({ fields }) => fields.year);
  let course = education.map(({ fields }) => fields.course);

  //project
  let projectName = project.map(({ fields }) => fields.name);
  let projectTechStack = project.map(({ fields }) => fields.techStack);
  const regex2 = /theend,/gi;
  projectStack = projectTechStack.toString().replace(regex2, "theend");

  let projectDesc = project.map(({ fields }) => fields.description);
  let projectDuration = project.map(({ fields }) => fields.duration);
  projectDesc = projectDesc.toString().replace(/(\r\n|\n|\r)/gm, " ");

  let projDesc = projectDesc.replace(regex, "theend &#9679");

  return {
    entry: "./index.js",
    output: {
      filename: "bundle.js",
      path: path.resolve(__dirname + "/dist"),
    },
    target: "node",
    plugins: [
      new HtmlWebpackPlugin({
        template: "index.html",
        title: "HTML Webpack Plugin",
        basicInfo: basicDetails,
        skillNames: skillsNames,
        skill1: skill1,
        skill2: skill2,
        skill3: skill3,
        skill4: skill4,
        position: position,
        duration: duration,
        company: company,
        desc: desc,
        degree: degree,
        place: place,
        year: year,
        course: course,
        projectName: projectName,
        projectDescription: projDesc,
        projectDuration: projectDuration,
        projectTechStack: projectStack,
      }),
    ],
  };
};
module.exports = doAsync;
